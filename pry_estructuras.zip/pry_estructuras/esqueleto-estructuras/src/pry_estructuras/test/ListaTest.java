package pry_estructuras.test;

import junit.framework.TestCase;

public class ListaTest extends TestCase{
   
  public void testSample() {
    assertEquals(2, 2);
  }
  
}