package pry_estructuras;

import estructuras.cola.ICola;
import java.util.Iterator;

public class Cola<T extends Comparable<T>> implements ICola<T> {
  
public int  darTamanio()
{
  return 0;
}
  
public T decolar()
{
  return null;
}

public void  encolar(T elemento)
{
  return;
}

public boolean  estaVacia()
{
  return false;
}

public Iterator<T> iterator()
{
  return null;
}

}