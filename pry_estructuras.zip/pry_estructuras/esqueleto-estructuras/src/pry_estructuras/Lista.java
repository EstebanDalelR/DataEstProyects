package pry_estructuras;

import estructuras.lista.ILista;
import java.util.Iterator;

public class Lista<T> implements ILista<T>
{
  

}
