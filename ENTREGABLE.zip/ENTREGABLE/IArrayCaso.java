package pry_estructuras;

import estructuras.lista.ILista;
import java.util.Iterator;

public interface IArrayCaso extends Array
{

  P
  public boolean agregar(Caso input)
  {
    add(input);
    return true;
  }
  public boolean eliminar(Caso input)
  {
    delete(input);
    return true;
  }
}