package api.proyecto1.interfaces.centralvehiculos;
public class Node <EventoVehiculo>{
EventoVehiculo element;
Node next;
public Node(EventoVehiculo ele, Node link){
elemnt=ele;
next=link;
}
}