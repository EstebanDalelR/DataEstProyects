package api.proyecto1.interfaces.centralllamadas;

/*
 * Estado se refiere al enum de estados de un caso
 * Cada caso puede estar abierto o cerrado
 */
public enum EstadoCaso {
 ABIERTO,
 CERRADO
}
