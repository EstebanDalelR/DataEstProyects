package api.proyecto1.interfaces.centralllamadas;

/*
 * CategoriaCaso se refiere al enum de categor�as para los casos
 * Cada caso tiene una categor�a, las categor�as son Pregunta, Queja o Reclamo
 */
public enum CategoriaCaso {
 PREGUNTA,
 QUEJA,
 RECLAMO
}
