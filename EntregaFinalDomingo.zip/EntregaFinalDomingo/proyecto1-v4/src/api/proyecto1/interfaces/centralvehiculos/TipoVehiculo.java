package api.proyecto1.interfaces.centralvehiculos;

/*
 * TipoVehiculo se refiere a los tipos de vehiculo que pueden recibir la central de vehiculo
 */
public enum TipoVehiculo{
CAMION,
FURGON,

}